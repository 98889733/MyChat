package com.mychat.app

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Msg(val id: String, val uid: String, val name: String, val text: String, val time: Date?)
class UserRow(val id: String, val name: String, val muted: Long, val banned: Long)

class MainActivity : AppCompatActivity() {
    private val red = Color.parseColor("#D50000")
    private val darkRed = Color.parseColor("#7F0000")
    private val gold = Color.parseColor("#FFB300")
    private val bg = Color.parseColor("#0D0D0D")
    private val card = Color.parseColor("#1C1C1C")
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val prefs by lazy { getSharedPreferences("chat", MODE_PRIVATE) }
    private val msgs = ArrayList<Msg>()
    private var reg: ListenerRegistration? = null
    private var userReg: ListenerRegistration? = null
    private var isAdmin = false
    private var me = ""
    private var myName = ""
    private var mutedUntil = 0L
    private var banned = false
    private var shield: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val n = prefs.getString("name", "") ?: ""
        if (prefs.getBoolean("auto", false) && n.isNotEmpty()) enter(n) else showLogin()
    }

    override fun onDestroy() {
        reg?.remove()
        userReg?.remove()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun stopListeners() {
        reg?.remove(); reg = null
        userReg?.remove(); userReg = null
    }

    private fun bigButton(t: String, color: Int) = Button(this).apply {
        text = t
        textSize = 18f
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
    }

    private fun showLogin() {
        stopListeners()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        val title = TextView(this).apply {
            text = "МЕСЕНДЖЕР"
            setTextColor(red)
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "Введіть своє ім'я, щоб увійти в чат"
            setTextColor(Color.LTGRAY)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(24))
        }
        val nameEt = EditText(this).apply {
            hint = "Ваше ім'я"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 20f
            setBackgroundColor(card)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            filters = arrayOf(InputFilter.LengthFilter(24))
            setText(prefs.getString("name", ""))
            setSingleLine()
        }
        val go = bigButton("УВІЙТИ", red)
        go.setOnClickListener {
            val n = nameEt.text.toString().trim()
            if (n.isEmpty()) {
                toast("Введіть ім'я")
                return@setOnClickListener
            }
            prefs.edit().putString("name", n).putBoolean("auto", true).apply()
            go.isEnabled = false
            enter(n)
        }
        box.addView(title)
        box.addView(sub)
        box.addView(nameEt, LinearLayout.LayoutParams(-1, -2))
        box.addView(View(this), LinearLayout.LayoutParams(-1, dp(16)))
        box.addView(go, LinearLayout.LayoutParams(-1, dp(64)))
        setContentView(box)
    }

    private fun enter(name: String) {
        fun step2() {
            val uid = auth.currentUser?.uid ?: return showLogin()
            db.collection("users").document(uid).set(hashMapOf("name" to name), SetOptions.merge())
                .addOnSuccessListener {
                    db.collection("admins").document(uid).get().addOnCompleteListener { t ->
                        isAdmin = t.isSuccessful && (t.result?.exists() == true)
                        showChat(name, uid)
                    }
                }
                .addOnFailureListener {
                    toast("Помилка входу: ${it.message}")
                    showLogin()
                }
        }
        if (auth.currentUser != null) {
            step2()
        } else {
            auth.signInAnonymously()
                .addOnSuccessListener { step2() }
                .addOnFailureListener {
                    toast("Помилка входу: ${it.message}")
                    showLogin()
                }
        }
    }

    private fun showBanned(until: Long) {
        banned = true
        reg?.remove(); reg = null
        val f = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        val t = TextView(this).apply {
            text = "Вас заблоковано\nдо ${f.format(Date(until))}"
            setTextColor(red)
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        }
        val again = bigButton("ПЕРЕВІРИТИ ЗНОВУ", red)
        again.setOnClickListener { enter(myName) }
        val out = bigButton("ВИЙТИ", darkRed)
        out.setOnClickListener {
            prefs.edit().putBoolean("auto", false).apply()
            showLogin()
        }
        box.addView(t)
        box.addView(again, LinearLayout.LayoutParams(-1, dp(64)))
        box.addView(View(this), LinearLayout.LayoutParams(-1, dp(12)))
        box.addView(out, LinearLayout.LayoutParams(-1, dp(64)))
        setContentView(box)
    }

    private fun showChat(name: String, uid: String) {
        me = uid
        myName = name
        banned = false
        mutedUntil = 0L
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(red)
            setPadding(dp(16), dp(8), dp(8), dp(8))
        }
        val t = TextView(this).apply {
            text = "ЗАГАЛЬНИЙ ЧАТ"
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        }
        val sh = Button(this).apply {
            text = "🛡"
            textSize = 22f
            setBackgroundColor(if (isAdmin) gold else darkRed)
        }
        shield = sh
        sh.setOnClickListener { if (isAdmin) showUsers() else askPassword() }
        val out = bigButton("ВИЙТИ", darkRed)
        out.setOnClickListener {
            prefs.edit().putBoolean("auto", false).apply()
            showLogin()
        }
        bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(sh, LinearLayout.LayoutParams(dp(56), dp(56)))
        bar.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
        bar.addView(out, LinearLayout.LayoutParams(-2, dp(56)))

        val list = ListView(this).apply {
            divider = null
            dividerHeight = 0
        }
        list.adapter = object : BaseAdapter() {
            override fun getCount() = msgs.size
            override fun getItem(p: Int) = msgs[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val m = msgs[p]
                val mine = m.uid == uid
                val ctx = this@MainActivity
                val wrap = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = if (mine) Gravity.END else Gravity.START
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                }
                val bubble = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundColor(if (mine) darkRed else card)
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                }
                val who = if (mine) "Ви" else m.name
                val head = TextView(ctx).apply {
                    text = who + (m.time?.let { "  " + fmt.format(it) } ?: "")
                    setTextColor(if (mine) Color.LTGRAY else red)
                    textSize = 12f
                }
                val body = TextView(ctx).apply {
                    text = m.text
                    setTextColor(Color.WHITE)
                    textSize = 17f
                }
                bubble.addView(head)
                bubble.addView(body)
                wrap.addView(bubble, LinearLayout.LayoutParams(-2, -2))
                return wrap
            }
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            if (isAdmin && pos < msgs.size) {
                val m = msgs[pos]
                AlertDialog.Builder(this)
                    .setTitle("Видалити повідомлення?")
                    .setMessage("${m.name}: ${m.text}")
                    .setPositiveButton("ВИДАЛИТИ") { _, _ ->
                        db.collection("messages").document(m.id).delete()
                            .addOnFailureListener { toast("Не вдалося видалити: ${it.message}") }
                    }
                    .setNegativeButton("Скасувати", null)
                    .show()
            }
            true
        }

        val input = EditText(this).apply {
            hint = "Повідомлення"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 18f
            setBackgroundColor(card)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            filters = arrayOf(InputFilter.LengthFilter(500))
            maxLines = 4
        }
        val send = bigButton("НАДІСЛАТИ", red)
        send.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            val now = System.currentTimeMillis()
            if (now < mutedUntil) {
                toast("Ви в муті до ${fmt.format(Date(mutedUntil))}")
                return@setOnClickListener
            }
            input.setText("")
            db.collection("messages").add(
                hashMapOf(
                    "uid" to uid,
                    "name" to name,
                    "text" to text,
                    "time" to FieldValue.serverTimestamp()
                )
            ).addOnFailureListener {
                toast("Не вдалося надіслати: ${it.message}")
            }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
        row.addView(send, LinearLayout.LayoutParams(-2, dp(64)))

        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(row, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        stopListeners()
        userReg = db.collection("users").document(uid).addSnapshotListener { s, e ->
            if (e != null || s == null) return@addSnapshotListener
            val b = s.getLong("bannedUntil") ?: 0L
            mutedUntil = s.getLong("mutedUntil") ?: 0L
            if (b > System.currentTimeMillis()) showBanned(b)
        }
        reg = db.collection("messages").orderBy("time").limitToLast(200)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    if (!banned) toast("Помилка чату: ${e.message}")
                    return@addSnapshotListener
                }
                msgs.clear()
                snap?.documents?.forEach { d ->
                    msgs.add(
                        Msg(
                            d.id,
                            d.getString("uid") ?: "",
                            d.getString("name") ?: "?",
                            d.getString("text") ?: "",
                            d.getTimestamp("time", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()
                        )
                    )
                }
                (list.adapter as BaseAdapter).notifyDataSetChanged()
                list.setSelection(msgs.size - 1)
            }
    }

    private fun askPassword() {
        val et = EditText(this).apply {
            hint = "Пароль"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 20f
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("Вхід для адмінів")
            .setView(et)
            .setPositiveButton("УВІЙТИ") { _, _ ->
                db.collection("admins").document(me)
                    .set(hashMapOf("code" to et.text.toString().trim()))
                    .addOnSuccessListener {
                        isAdmin = true
                        shield?.setBackgroundColor(gold)
                        toast("Тепер ви адмін")
                        showUsers()
                    }
                    .addOnFailureListener { toast("Неправильний пароль") }
            }
            .setNegativeButton("Скасувати", null)
            .show()
    }

    private fun showUsers() {
        db.collection("users").get().addOnSuccessListener { snap ->
            val rows = snap.documents.map {
                UserRow(
                    it.id,
                    it.getString("name") ?: "?",
                    it.getLong("mutedUntil") ?: 0L,
                    it.getLong("bannedUntil") ?: 0L
                )
            }
            val now = System.currentTimeMillis()
            val labels = rows.map { r ->
                r.name +
                    (if (r.banned > now) "  [БАН]" else "") +
                    (if (r.muted > now) "  [МУТ]" else "") +
                    (if (r.id == me) "  (ви)" else "")
            }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Гравці")
                .setItems(labels) { _, i -> userActions(rows[i]) }
                .setNegativeButton("Закрити", null)
                .show()
        }.addOnFailureListener { toast("Помилка: ${it.message}") }
    }

    private fun userActions(r: UserRow) {
        if (r.id == me) {
            toast("Це ви. На себе не можна")
            return
        }
        val items = arrayOf(
            "Мут 1 хвилина", "Мут 5 хвилин", "Мут 10 хвилин", "Зняти мут",
            "Бан 1 година", "Бан 1 доба", "Бан на свій час…", "Зняти бан"
        )
        AlertDialog.Builder(this)
            .setTitle(r.name)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> setUntil(r, "mutedUntil", 1)
                    1 -> setUntil(r, "mutedUntil", 5)
                    2 -> setUntil(r, "mutedUntil", 10)
                    3 -> setUntil(r, "mutedUntil", 0)
                    4 -> setUntil(r, "bannedUntil", 60)
                    5 -> setUntil(r, "bannedUntil", 1440)
                    6 -> askMinutes(r)
                    7 -> setUntil(r, "bannedUntil", 0)
                }
            }
            .setNegativeButton("Назад", null)
            .show()
    }

    private fun askMinutes(r: UserRow) {
        val et = EditText(this).apply {
            hint = "Хвилин (60 = година, 1440 = доба)"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 18f
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(7))
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("Бан: ${r.name}")
            .setView(et)
            .setPositiveButton("ЗАБАНИТИ") { _, _ ->
                val n = et.text.toString().toLongOrNull() ?: 0L
                if (n > 0) setUntil(r, "bannedUntil", n) else toast("Введіть число більше нуля")
            }
            .setNegativeButton("Скасувати", null)
            .show()
    }

    private fun setUntil(r: UserRow, field: String, minutes: Long) {
        val v = if (minutes <= 0) 0L else System.currentTimeMillis() + minutes * 60000L
        db.collection("users").document(r.id).update(field, v)
            .addOnSuccessListener { toast("Готово") }
            .addOnFailureListener { toast("Помилка: ${it.message}") }
    }
}
