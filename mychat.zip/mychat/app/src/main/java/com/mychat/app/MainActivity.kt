package com.mychat.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Msg(
    val id: String, val uid: String, val name: String, val text: String,
    val time: Date?, val audio: String?, val dur: Long
)

class UserRow(val id: String, val name: String, val muted: Long, val banned: Long, val seen: Long)
class ChatRow(val id: String, val an: String, val bn: String, val last: Date?)

class MainActivity : AppCompatActivity() {
    private val cBg = Color.parseColor("#0B0B0F")
    private val cBar = Color.parseColor("#15151B")
    private val cCard = Color.parseColor("#1E1E26")
    private val cRed = Color.parseColor("#E53935")
    private val cRedDark = Color.parseColor("#8E0000")
    private val cGold = Color.parseColor("#FFB300")
    private val cGreen = Color.parseColor("#43A047")
    private val cOrange = Color.parseColor("#FB8C00")
    private val cGray = Color.parseColor("#8A8A94")
    private val cWhite = Color.WHITE

    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val prefs by lazy { getSharedPreferences("chat", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())

    private var reg: ListenerRegistration? = null
    private var userReg: ListenerRegistration? = null
    private var isAdmin = false
    private var me = ""
    private var myName = ""
    private var mutedUntil = 0L
    private var banned = false

    private lateinit var backCb: OnBackPressedCallback
    private lateinit var content: FrameLayout
    private lateinit var drawer: LinearLayout
    private lateinit var scrim: View
    private lateinit var titleTv: TextView
    private lateinit var subTv: TextView
    private var shieldTv: TextView? = null
    private var drawerOpen = false
    private var current = "general"

    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    private var recStart = 0L
    private var recSend: ((String, Long) -> Unit)? = null
    private var recUi: ((Boolean) -> Unit)? = null
    private var player: MediaPlayer? = null
    private var playingId = ""

    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        toast(if (ok) "Дозвіл надано. Натисніть 🎤 ще раз" else "Без дозволу голосові не працюють")
    }

    private val beat = object : Runnable {
        override fun run() {
            if (me.isNotEmpty()) {
                db.collection("users").document(me).update("lastSeen", System.currentTimeMillis())
            }
            handler.postDelayed(this, 30000)
        }
    }

    // ---------- життєвий цикл ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backCb = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() { goBack() }
        }
        onBackPressedDispatcher.addCallback(this, backCb)
        val n = prefs.getString("name", "") ?: ""
        if (prefs.getBoolean("auto", false) && n.isNotEmpty()) enter(n) else showLogin()
    }

    override fun onStart() {
        super.onStart()
        if (me.isNotEmpty()) { handler.removeCallbacks(beat); handler.post(beat) }
    }

    override fun onStop() {
        handler.removeCallbacks(beat)
        endRec(false)
        stopAudio()
        super.onStop()
    }

    override fun onDestroy() {
        reg?.remove()
        userReg?.remove()
        super.onDestroy()
    }

    private fun goBack() {
        if (drawerOpen) { closeDrawer(); return }
        if (current == "spy") { openAdmin(); return }
        if (current != "general") { openGeneral(); return }
        backCb.isEnabled = false
        onBackPressedDispatcher.onBackPressed()
    }

    // ---------- допоміжне оформлення ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

    private fun rect(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun redGradient(r: Int) =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cRed, cRedDark)).apply {
            cornerRadius = dp(r).toFloat()
        }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun pill(t: String, color: Int) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(cWhite)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        maxLines = 1
        background = rect(color, 12)
        setPadding(dp(6), dp(10), dp(6), dp(10))
    }

    private fun colorFor(s: String): Int {
        val cs = intArrayOf(
            0xFFE53935.toInt(), 0xFFFB8C00.toInt(), 0xFF43A047.toInt(), 0xFF1E88E5.toInt(),
            0xFF8E24AA.toInt(), 0xFF00ACC1.toInt(), 0xFFD81B60.toInt(), 0xFFFDD835.toInt()
        )
        return cs[(s.hashCode() and 0x7fffffff) % cs.size]
    }

    private fun avatar(name: String) = TextView(this).apply {
        text = name.take(1).uppercase()
        gravity = Gravity.CENTER
        setTextColor(cWhite)
        typeface = Typeface.DEFAULT_BOLD
        textSize = 18f
        background = oval(colorFor(name))
    }

    private fun fmtDur(s: Long) = "%d:%02d".format(s / 60, s % 60)

    private fun <T> listAdapter(items: List<T>, build: (T) -> View): BaseAdapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int): Any? = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup): View = build(items[p])
    }

    private fun newList() = ListView(this).apply {
        divider = null
        dividerHeight = 0
        setBackgroundColor(cBg)
    }

    private fun stopListeners() {
        reg?.remove(); reg = null
        userReg?.remove(); userReg = null
    }

    // ---------- вхід ----------

    private fun showLogin() {
        stopListeners()
        handler.removeCallbacks(beat)
        me = ""
        backCb.isEnabled = false
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cBg)
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        val title = label("МЕСЕНДЖЕР", 32f, cRed, true).apply { gravity = Gravity.CENTER }
        val sub = label("Введіть своє ім'я, щоб увійти в чат", 16f, Color.LTGRAY).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(24))
        }
        val nameEt = EditText(this).apply {
            hint = "Ваше ім'я"
            setHintTextColor(cGray)
            setTextColor(cWhite)
            textSize = 20f
            background = rect(cCard, 16)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            filters = arrayOf(InputFilter.LengthFilter(24))
            setText(prefs.getString("name", ""))
            setSingleLine()
        }
        val go = pill("УВІЙТИ", cRed).apply { textSize = 18f }
        go.setOnClickListener {
            val n = nameEt.text.toString().trim()
            if (n.isEmpty()) {
                toast("Введіть ім'я")
                return@setOnClickListener
            }
            prefs.edit().putString("name", n).putBoolean("auto", true).apply()
            go.isEnabled = false
            enter(n)
        }
        box.addView(title)
        box.addView(sub)
        box.addView(nameEt, lp(-1, -2))
        box.addView(View(this), lp(-1, dp(16)))
        box.addView(go, lp(-1, dp(64)))
        setContentView(box)
    }

    private fun enter(name: String) {
        fun step2() {
            val uid = auth.currentUser?.uid
            if (uid == null) { showLogin(); return }
            val data = hashMapOf<String, Any>("name" to name, "lastSeen" to System.currentTimeMillis())
            db.collection("users").document(uid).set(data, SetOptions.merge())
                .addOnSuccessListener {
                    db.collection("admins").document(uid).get().addOnCompleteListener { t ->
                        isAdmin = t.isSuccessful && (t.result?.exists() == true)
                        showMain(name, uid)
                    }
                }
                .addOnFailureListener {
                    toast("Помилка входу: ${it.message}")
                    showLogin()
                }
        }
        if (auth.currentUser != null) {
            step2()
        } else {
            auth.signInAnonymously()
                .addOnSuccessListener { step2() }
                .addOnFailureListener {
                    toast("Помилка входу: ${it.message}")
                    showLogin()
                }
        }
    }

    private fun showBanned(until: Long) {
        banned = true
        reg?.remove(); reg = null
        backCb.isEnabled = false
        val f = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cBg)
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        val t = label("⛔\nВас заблоковано\nдо ${f.format(Date(until))}", 26f, cRed, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        }
        val again = pill("ПЕРЕВІРИТИ ЗНОВУ", cRed).apply { textSize = 17f }
        again.setOnClickListener { enter(myName) }
        val out = pill("ВИЙТИ", cCard).apply { textSize = 17f }
        out.setOnClickListener {
            prefs.edit().putBoolean("auto", false).apply()
            showLogin()
        }
        box.addView(t)
        box.addView(again, lp(-1, dp(60)))
        box.addView(View(this), lp(-1, dp(12)))
        box.addView(out, lp(-1, dp(60)))
        setContentView(box)
    }

    // ---------- каркас: верхня панель + бічне меню ----------

    private fun showMain(name: String, uid: String) {
        me = uid
        myName = name
        banned = false
        mutedUntil = 0L
        drawerOpen = false
        stopListeners()

        val root = FrameLayout(this).apply { setBackgroundColor(cBg) }
        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(cBar)
        }
        val menu = label("☰", 28f, cWhite).apply { gravity = Gravity.CENTER }
        menu.setOnClickListener { if (drawerOpen) closeDrawer() else openDrawer() }
        titleTv = label("", 19f, cWhite, true).apply { maxLines = 1 }
        subTv = label("", 12f, cGray).apply { maxLines = 1 }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleTv)
            addView(subTv)
        }
        val sh = label("🛡", 24f, cWhite).apply {
            gravity = Gravity.CENTER
            background = oval(if (isAdmin) cGold else cCard)
        }
        sh.setOnClickListener { openAdmin() }
        shieldTv = sh
        bar.addView(menu, lp(dp(60), dp(60)))
        bar.addView(titles, lp(0, -2, 1f))
        bar.addView(sh, lp(dp(46), dp(46)).apply { rightMargin = dp(12) })
        main.addView(bar, lp(-1, -2))
        main.addView(View(this).apply { setBackgroundColor(cRed) }, lp(-1, dp(2)))

        content = FrameLayout(this)
        main.addView(content, lp(-1, 0, 1f))
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        scrim = View(this).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
            visibility = View.GONE
            setOnClickListener { closeDrawer() }
        }
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBar)
            translationX = -dp(290).toFloat()
            isClickable = true
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(44), dp(20), dp(20))
            background = redGradient(0)
        }
        head.addView(avatar(myName), lp(dp(60), dp(60)))
        head.addView(label(myName, 20f, cWhite, true).apply { setPadding(0, dp(10), 0, 0) })
        head.addView(label("● онлайн", 13f, Color.parseColor("#B9F6CA")))
        drawer.addView(head, lp(-1, -2))
        drawer.addView(drawerItem("🌐", "Загальний чат") { openGeneral() })
        drawer.addView(drawerItem("🔒", "Приватні чати") { openPeople() })
        drawer.addView(drawerItem("🛡", "Адмін-панель") { openAdmin() })
        drawer.addView(View(this), lp(-1, 0, 1f))
        drawer.addView(drawerItem("🚪", "Вийти") {
            prefs.edit().putBoolean("auto", false).apply()
            showLogin()
        })
        root.addView(drawer, FrameLayout.LayoutParams(dp(290), -1))

        setContentView(root)
        backCb.isEnabled = true

        userReg = db.collection("users").document(uid).addSnapshotListener { s, e ->
            if (e != null || s == null) return@addSnapshotListener
            val b = s.getLong("bannedUntil") ?: 0L
            mutedUntil = s.getLong("mutedUntil") ?: 0L
            if (b > System.currentTimeMillis()) showBanned(b)
        }
        handler.removeCallbacks(beat)
        handler.post(beat)
        openGeneral()
    }

    private fun drawerItem(icon: String, text: String, onClick: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(18))
            addView(label(icon, 22f, cWhite))
            addView(label("   $text", 18f, cWhite))
            setOnClickListener { closeDrawer(); onClick() }
        }

    private fun openDrawer() {
        drawerOpen = true
        scrim.visibility = View.VISIBLE
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(180)
        drawer.animate().translationX(0f).setDuration(180)
    }

    private fun closeDrawer() {
        drawerOpen = false
        scrim.animate().alpha(0f).setDuration(180).withEndAction { scrim.visibility = View.GONE }
        drawer.animate().translationX(-dp(290).toFloat()).setDuration(180)
    }

    private fun newScreen() {
        reg?.remove()
        reg = null
    }

    private fun show(key: String, title: String, sub: String, v: View) {
        endRec(false)
        stopAudio()
        current = key
        titleTv.text = title
        subTv.text = sub
        content.removeAllViews()
        content.addView(v, FrameLayout.LayoutParams(-1, -1))
    }

    // ---------- екрани ----------

    private fun openGeneral() {
        newScreen()
        val v = chatView(db.collection("messages"), false, null, null)
        show("general", "Загальний чат", "для всіх", v)
    }

    private fun online(u: UserRow) = System.currentTimeMillis() - u.seen < 75000

    private fun personCard(u: UserRow, sub: String, subColor: Int): View {
        val outer = LinearLayout(this).apply { setPadding(dp(12), dp(5), dp(12), dp(5)) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rect(cCard, 16)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        card.addView(avatar(u.name), lp(dp(48), dp(48)).apply { rightMargin = dp(12) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(u.name, 18f, cWhite, true))
        col.addView(label(sub, 13f, subColor))
        card.addView(col, lp(0, -2, 1f))
        outer.addView(card, lp(-1, -2))
        return outer
    }

    private fun readUsers(snap: com.google.firebase.firestore.QuerySnapshot?): ArrayList<UserRow> {
        val out = ArrayList<UserRow>()
        snap?.documents?.forEach { d ->
            out.add(
                UserRow(
                    d.id,
                    d.getString("name") ?: "?",
                    d.getLong("mutedUntil") ?: 0L,
                    d.getLong("bannedUntil") ?: 0L,
                    d.getLong("lastSeen") ?: 0L
                )
            )
        }
        out.sortWith(compareBy<UserRow> { !online(it) }.thenBy { it.name.lowercase() })
        return out
    }

    private fun emptyText(t: String) = label(t, 16f, cGray).apply {
        gravity = Gravity.CENTER
        setPadding(dp(24), dp(24), dp(24), dp(24))
    }

    private fun openPeople() {
        newScreen()
        val rows = ArrayList<UserRow>()
        val list = newList()
        val empty = emptyText("Поки що тут нікого немає")
        val ad = listAdapter(rows) { u ->
            if (online(u)) personCard(u, "● онлайн", cGreen) else personCard(u, "не в мережі", cGray)
        }
        list.adapter = ad
        list.emptyView = empty
        list.setOnItemClickListener { _, _, pos, _ -> openDm(rows[pos]) }
        val box = FrameLayout(this)
        box.addView(list, FrameLayout.LayoutParams(-1, -1))
        box.addView(empty, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        reg = db.collection("users").addSnapshotListener { snap, e ->
            if (e != null) { toast("Помилка: ${e.message}"); return@addSnapshotListener }
            rows.clear()
            rows.addAll(readUsers(snap).filter { it.id != me })
            ad.notifyDataSetChanged()
        }
        show("people", "Приватні чати", "оберіть, кому написати", box)
    }

    private fun openDm(u: UserRow) {
        newScreen()
        val a = if (me < u.id) me else u.id
        val b = if (me < u.id) u.id else me
        val an = if (a == me) myName else u.name
        val bn = if (b == me) myName else u.name
        val chatId = a + "_" + b
        val meta = db.collection("chats").document(chatId)
        val v = chatView(
            meta.collection("messages"), false,
            "🔒 Приватний чат. Адміни можуть переглядати приватні чати."
        ) {
            meta.set(
                hashMapOf<String, Any>(
                    "a" to a, "b" to b, "an" to an, "bn" to bn,
                    "last" to FieldValue.serverTimestamp()
                )
            )
        }
        show("dm", u.name, "приватний чат", v)
    }

    // ---------- чат (спільний для загального, приватного та перегляду) ----------

    private fun bubble(m: Msg): View {
        val mine = m.uid == me
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (mine) Gravity.END else Gravity.START
            setPadding(dp(10), dp(3), dp(10), dp(3))
        }
        if (!mine) wrap.addView(avatar(m.name), lp(dp(34), dp(34)).apply { rightMargin = dp(6) })
        val bub = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(6))
            background = if (mine) redGradient(16) else rect(cCard, 16)
        }
        if (!mine) bub.addView(label(m.name, 12f, colorFor(m.name), true))
        if (m.audio != null) {
            val vr = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val play = label(if (playingId == m.id) "⏹" else "▶", 20f, cWhite).apply {
                gravity = Gravity.CENTER
                background = oval(Color.parseColor("#33FFFFFF"))
            }
            vr.addView(play, lp(dp(42), dp(42)))
            vr.addView(label("   🎤 ${fmtDur(m.dur)}", 16f, cWhite))
            vr.setOnClickListener {
                if (playingId == m.id) stopAudio() else playAudio(m)
            }
            bub.addView(vr)
        } else {
            bub.addView(label(m.text, 17f, cWhite))
        }
        val tm = label(m.time?.let { fmt.format(it) } ?: "", 11f, Color.parseColor("#99FFFFFF")).apply {
            gravity = Gravity.END
        }
        bub.addView(tm, lp(-1, -2))
        wrap.addView(bub, lp(-2, -2))
        return wrap
    }

    private fun chatView(
        col: CollectionReference, readOnly: Boolean, notice: String?, onSent: (() -> Unit)?
    ): View {
        val msgs = ArrayList<Msg>()
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
        }
        if (notice != null) {
            val nt = label(notice, 12f, cGray).apply {
                gravity = Gravity.CENTER
                setBackgroundColor(cBar)
                setPadding(dp(16), dp(8), dp(16), dp(8))
            }
            box.addView(nt, lp(-1, -2))
        }
        val list = newList()
        val ad = listAdapter(msgs) { m -> bubble(m) }
        list.adapter = ad
        list.setOnItemLongClickListener { _, _, pos, _ ->
            if (isAdmin && pos < msgs.size) {
                val m = msgs[pos]
                AlertDialog.Builder(this)
                    .setTitle("Видалити повідомлення?")
                    .setMessage(if (m.audio != null) "${m.name}: 🎤 голосове" else "${m.name}: ${m.text}")
                    .setPositiveButton("ВИДАЛИТИ") { _, _ ->
                        col.document(m.id).delete()
                            .addOnFailureListener { toast("Не вдалося видалити: ${it.message}") }
                    }
                    .setNegativeButton("Скасувати", null)
                    .show()
            }
            true
        }
        box.addView(list, lp(-1, 0, 1f))

        if (!readOnly) {
            val input = EditText(this).apply {
                hint = "Повідомлення"
                setHintTextColor(cGray)
                setTextColor(cWhite)
                textSize = 17f
                background = rect(cCard, 26)
                setPadding(dp(18), dp(12), dp(18), dp(12))
                filters = arrayOf(InputFilter.LengthFilter(500))
                maxLines = 4
            }
            val mic = label("🎤", 22f, cWhite).apply {
                gravity = Gravity.CENTER
                background = oval(cCard)
            }
            val send = label("➤", 22f, cWhite).apply {
                gravity = Gravity.CENTER
                background = oval(cRed)
            }

            fun post(text: String, audio: String?, dur: Long) {
                if (System.currentTimeMillis() < mutedUntil) {
                    toast("Ви в муті до ${fmt.format(Date(mutedUntil))}")
                    return
                }
                val data = hashMapOf<String, Any>(
                    "uid" to me, "name" to myName, "text" to text,
                    "time" to FieldValue.serverTimestamp()
                )
                if (audio != null) {
                    data["audio"] = audio
                    data["dur"] = dur
                }
                onSent?.invoke()
                col.add(data).addOnFailureListener { toast("Не вдалося надіслати: ${it.message}") }
            }

            send.setOnClickListener {
                val text = input.text.toString().trim()
                if (text.isEmpty()) return@setOnClickListener
                input.setText("")
                post(text, null, 0L)
            }
            mic.setOnClickListener {
                if (recorder == null) {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        micPerm.launch(Manifest.permission.RECORD_AUDIO)
                        return@setOnClickListener
                    }
                    recSend = { a, d -> post("", a, d) }
                    recUi = { on ->
                        mic.text = if (on) "⏹" else "🎤"
                        mic.background = oval(if (on) cRed else cCard)
                        input.hint = if (on) "Іде запис… натисніть ⏹" else "Повідомлення"
                    }
                    beginRec()
                } else {
                    endRec(true)
                }
            }

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(cBar)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            row.addView(input, lp(0, -2, 1f))
            row.addView(mic, lp(dp(52), dp(52)).apply { leftMargin = dp(8) })
            row.addView(send, lp(dp(52), dp(52)).apply { leftMargin = dp(8) })
            box.addView(row, lp(-1, -2))
        }

        reg = col.orderBy("time").limitToLast(200).addSnapshotListener { snap, e ->
            if (e != null) {
                if (!banned) toast("Помилка чату: ${e.message}")
                return@addSnapshotListener
            }
            msgs.clear()
            snap?.documents?.forEach { d ->
                msgs.add(
                    Msg(
                        d.id,
                        d.getString("uid") ?: "",
                        d.getString("name") ?: "?",
                        d.getString("text") ?: "",
                        d.getTimestamp("time", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate(),
                        d.getString("audio"),
                        d.getLong("dur") ?: 0L
                    )
                )
            }
            ad.notifyDataSetChanged()
            list.setSelection(msgs.size - 1)
        }
        return box
    }

    // ---------- голосові ----------

    private fun beginRec() {
        stopAudio()
        try {
            val f = File(cacheDir, "rec.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(16000)
            r.setAudioEncodingBitRate(24000)
            r.setMaxDuration(60000)
            r.setOutputFile(f.absolutePath)
            r.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) endRec(true)
            }
            r.prepare()
            r.start()
            recorder = r
            recFile = f
            recStart = System.currentTimeMillis()
            recUi?.invoke(true)
        } catch (e: Exception) {
            recorder = null
            toast("Не вдалося почати запис: ${e.message}")
        }
    }

    private fun endRec(send: Boolean) {
        val r = recorder ?: return
        recorder = null
        var ok = send
        val secs = (System.currentTimeMillis() - recStart) / 1000
        try {
            r.stop()
        } catch (e: Exception) {
            ok = false
        }
        try { r.release() } catch (e: Exception) { }
        recUi?.invoke(false)
        if (!ok) {
            if (send) toast("Запис занадто короткий")
            return
        }
        if (secs < 1) {
            toast("Запис занадто короткий")
            return
        }
        val bytes = try { recFile?.readBytes() } catch (e: Exception) { null }
        if (bytes == null || bytes.isEmpty()) {
            toast("Не вдалося прочитати запис")
            return
        }
        if (bytes.size > 500_000) {
            toast("Запис занадто великий")
            return
        }
        recSend?.invoke(Base64.encodeToString(bytes, Base64.NO_WRAP), secs)
    }

    private fun playAudio(m: Msg) {
        stopAudio()
        val data = m.audio ?: return
        try {
            val f = File(cacheDir, "play.m4a")
            f.writeBytes(Base64.decode(data, Base64.DEFAULT))
            val p = MediaPlayer()
            p.setDataSource(f.absolutePath)
            p.setOnCompletionListener { stopAudio() }
            p.prepare()
            p.start()
            player = p
            playingId = m.id
        } catch (e: Exception) {
            stopAudio()
            toast("Не вдалося відтворити: ${e.message}")
        }
    }

    private fun stopAudio() {
        try { player?.release() } catch (e: Exception) { }
        player = null
        playingId = ""
    }

    // ---------- адмін ----------

    private fun askPassword() {
        val et = EditText(this).apply {
            hint = "Пароль"
            setHintTextColor(cGray)
            setTextColor(cWhite)
            textSize = 22f
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("🛡 Вхід для адмінів")
            .setView(et)
            .setPositiveButton("УВІЙТИ") { _, _ ->
                db.collection("admins").document(me)
                    .set(hashMapOf("code" to et.text.toString().trim()))
                    .addOnSuccessListener {
                        isAdmin = true
                        shieldTv?.background = oval(cGold)
                        toast("Тепер ви адмін")
                        openAdmin()
                    }
                    .addOnFailureListener { toast("Неправильний пароль") }
            }
            .setNegativeButton("Скасувати", null)
            .show()
    }

    private fun statusText(r: UserRow): String {
        val now = System.currentTimeMillis()
        val f = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        return when {
            r.banned > now -> "⛔ Бан до ${f.format(Date(r.banned))}"
            r.muted > now -> "🔇 Мут до ${f.format(Date(r.muted))}"
            online(r) -> "● онлайн"
            else -> "не в мережі"
        }
    }

    private fun statusColor(r: UserRow): Int {
        val now = System.currentTimeMillis()
        return when {
            r.banned > now -> cRed
            r.muted > now -> cOrange
            online(r) -> cGreen
            else -> cGray
        }
    }

    private fun openAdmin() {
        if (!isAdmin) {
            askPassword()
            return
        }
        newScreen()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
        }
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(10), dp(12), dp(6))
        }
        val t1 = pill("👥 Гравці", cRed).apply { textSize = 16f }
        val t2 = pill("👁 Переписки", cCard).apply { textSize = 16f }
        tabs.addView(t1, lp(0, dp(52), 1f).apply { rightMargin = dp(6) })
        tabs.addView(t2, lp(0, dp(52), 1f).apply { leftMargin = dp(6) })
        val body = FrameLayout(this)
        fun select(i: Int) {
            reg?.remove()
            reg = null
            t1.background = rect(if (i == 0) cRed else cCard, 12)
            t2.background = rect(if (i == 1) cRed else cCard, 12)
            body.removeAllViews()
            body.addView(if (i == 0) adminUsers() else adminChats(), FrameLayout.LayoutParams(-1, -1))
        }
        t1.setOnClickListener { select(0) }
        t2.setOnClickListener { select(1) }
        box.addView(tabs, lp(-1, -2))
        box.addView(body, lp(-1, 0, 1f))
        select(0)
        show("admin", "Адмін-панель", "керування чатом", box)
    }

    private fun adminUsers(): View {
        val rows = ArrayList<UserRow>()
        val list = newList()
        val empty = emptyText("Користувачів поки немає")
        val ad = listAdapter(rows) { u ->
            personCard(u, statusText(u) + if (u.id == me) "  (ви)" else "", statusColor(u))
        }
        list.adapter = ad
        list.emptyView = empty
        list.setOnItemClickListener { _, _, pos, _ -> userActions(rows[pos]) }
        val box = FrameLayout(this)
        box.addView(list, FrameLayout.LayoutParams(-1, -1))
        box.addView(empty, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        reg = db.collection("users").addSnapshotListener { snap, e ->
            if (e != null) { toast("Помилка: ${e.message}"); return@addSnapshotListener }
            rows.clear()
            rows.addAll(readUsers(snap))
            ad.notifyDataSetChanged()
        }
        return box
    }

    private fun adminChats(): View {
        val rows = ArrayList<ChatRow>()
        val list = newList()
        val empty = emptyText("Приватних переписок поки немає")
        val f = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val ad = listAdapter(rows) { c ->
            val outer = LinearLayout(this).apply { setPadding(dp(12), dp(5), dp(12), dp(5)) }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rect(cCard, 16)
                setPadding(dp(14), dp(14), dp(14), dp(14))
            }
            card.addView(label("💬", 24f, cWhite).apply { setPadding(0, 0, dp(12), 0) })
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(label("${c.an}  ↔  ${c.bn}", 17f, cWhite, true))
            col.addView(label(c.last?.let { "остання: " + f.format(it) } ?: "", 12f, cGray))
            card.addView(col, lp(0, -2, 1f))
            card.addView(label("👁", 20f, cGray))
            outer.addView(card, lp(-1, -2))
            outer
        }
        list.adapter = ad
        list.emptyView = empty
        list.setOnItemClickListener { _, _, pos, _ -> openSpy(rows[pos]) }
        val box = FrameLayout(this)
        box.addView(list, FrameLayout.LayoutParams(-1, -1))
        box.addView(empty, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        reg = db.collection("chats").orderBy("last", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snap, e ->
                if (e != null) { toast("Помилка: ${e.message}"); return@addSnapshotListener }
                rows.clear()
                snap?.documents?.forEach { d ->
                    rows.add(
                        ChatRow(
                            d.id,
                            d.getString("an") ?: "?",
                            d.getString("bn") ?: "?",
                            d.getTimestamp("last")?.toDate()
                        )
                    )
                }
                ad.notifyDataSetChanged()
            }
        return box
    }

    private fun openSpy(c: ChatRow) {
        newScreen()
        val v = chatView(
            db.collection("chats").document(c.id).collection("messages"), true,
            "👁 Режим перегляду: ви бачите чужу переписку і не можете писати", null
        )
        show("spy", "${c.an} ↔ ${c.bn}", "перегляд адміном", v)
    }

    private fun userActions(r: UserRow) {
        if (r.id == me) {
            toast("Це ви. На себе не можна")
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rect(cBar, 20)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val dlg = AlertDialog.Builder(this).setView(box).create()
        box.addView(label(r.name, 22f, cWhite, true))
        box.addView(label(statusText(r), 14f, statusColor(r)).apply { setPadding(0, dp(2), 0, dp(10)) })

        fun section(title: String, color: Int, items: List<Pair<String, () -> Unit>>) {
            box.addView(label(title, 13f, cGray, true).apply { setPadding(0, dp(10), 0, dp(6)) })
            val h = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            items.forEachIndexed { i, pair ->
                val c = if (pair.first == "Зняти") cGreen else color
                val b = pill(pair.first, c)
                b.setOnClickListener {
                    pair.second()
                    dlg.dismiss()
                }
                h.addView(b, lp(0, dp(52), 1f).apply { if (i > 0) leftMargin = dp(6) })
            }
            box.addView(h, lp(-1, -2))
        }
        section(
            "🔇 МУТ", cOrange, listOf(
                Pair("1 хв") { setUntil(r, "mutedUntil", 1) },
                Pair("5 хв") { setUntil(r, "mutedUntil", 5) },
                Pair("10 хв") { setUntil(r, "mutedUntil", 10) },
                Pair("Зняти") { setUntil(r, "mutedUntil", 0) }
            )
        )
        section(
            "⛔ БАН", cRed, listOf(
                Pair("1 год") { setUntil(r, "bannedUntil", 60) },
                Pair("1 доба") { setUntil(r, "bannedUntil", 1440) },
                Pair("Інше") { askMinutes(r) },
                Pair("Зняти") { setUntil(r, "bannedUntil", 0) }
            )
        )
        val close = pill("Закрити", cCard)
        close.setOnClickListener { dlg.dismiss() }
        box.addView(close, lp(-1, dp(50)).apply { topMargin = dp(16) })
        dlg.show()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun askMinutes(r: UserRow) {
        val et = EditText(this).apply {
            hint = "Хвилин (60 = година, 1440 = доба)"
            setHintTextColor(cGray)
            setTextColor(cWhite)
            textSize = 18f
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(7))
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("⛔ Бан: ${r.name}")
            .setView(et)
            .setPositiveButton("ЗАБАНИТИ") { _, _ ->
                val n = et.text.toString().toLongOrNull() ?: 0L
                if (n > 0) setUntil(r, "bannedUntil", n) else toast("Введіть число більше нуля")
            }
            .setNegativeButton("Скасувати", null)
            .show()
    }

    private fun setUntil(r: UserRow, field: String, minutes: Long) {
        val v = if (minutes <= 0) 0L else System.currentTimeMillis() + minutes * 60000L
        db.collection("users").document(r.id).update(field, v)
            .addOnSuccessListener { toast("Готово") }
            .addOnFailureListener { toast("Помилка: ${it.message}") }
    }

    private fun setUntil(r: UserRow, field: String, minutes: Int) = setUntil(r, field, minutes.toLong())
}
