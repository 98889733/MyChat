package com.mychat.app

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Msg(val uid: String, val name: String, val text: String, val time: Date?)

class MainActivity : AppCompatActivity() {
    private val red = Color.parseColor("#D50000")
    private val darkRed = Color.parseColor("#7F0000")
    private val bg = Color.parseColor("#0D0D0D")
    private val card = Color.parseColor("#1C1C1C")
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val prefs by lazy { getSharedPreferences("chat", MODE_PRIVATE) }
    private val msgs = ArrayList<Msg>()
    private var reg: ListenerRegistration? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    override fun onDestroy() {
        reg?.remove()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun bigButton(t: String, color: Int) = Button(this).apply {
        text = t
        textSize = 18f
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
    }

    private fun showLogin() {
        reg?.remove()
        reg = null
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        val title = TextView(this).apply {
            text = "МЕСЕНДЖЕР"
            setTextColor(red)
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "Введіть своє ім'я, щоб увійти в чат"
            setTextColor(Color.LTGRAY)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(24))
        }
        val nameEt = EditText(this).apply {
            hint = "Ваше ім'я"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 20f
            setBackgroundColor(card)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            filters = arrayOf(InputFilter.LengthFilter(24))
            setText(prefs.getString("name", ""))
            setSingleLine()
        }
        val go = bigButton("УВІЙТИ", red)
        go.setOnClickListener {
            val n = nameEt.text.toString().trim()
            if (n.isEmpty()) {
                toast("Введіть ім'я")
                return@setOnClickListener
            }
            prefs.edit().putString("name", n).apply()
            go.isEnabled = false
            if (auth.currentUser != null) {
                showChat(n)
            } else {
                auth.signInAnonymously()
                    .addOnSuccessListener { showChat(n) }
                    .addOnFailureListener {
                        go.isEnabled = true
                        toast("Помилка входу: ${it.message}")
                    }
            }
        }
        box.addView(title)
        box.addView(sub)
        box.addView(nameEt, LinearLayout.LayoutParams(-1, -2))
        box.addView(View(this), LinearLayout.LayoutParams(-1, dp(16)))
        box.addView(go, LinearLayout.LayoutParams(-1, dp(64)))
        setContentView(box)
    }

    private fun showChat(name: String) {
        val uid = auth.currentUser?.uid ?: ""
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(red)
            setPadding(dp(16), dp(8), dp(8), dp(8))
        }
        val t = TextView(this).apply {
            text = "ЗАГАЛЬНИЙ ЧАТ"
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
        }
        val out = bigButton("ВИЙТИ", darkRed)
        out.setOnClickListener { showLogin() }
        bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(out, LinearLayout.LayoutParams(-2, dp(56)))

        val list = ListView(this).apply {
            divider = null
            dividerHeight = 0
        }
        list.adapter = object : BaseAdapter() {
            override fun getCount() = msgs.size
            override fun getItem(p: Int) = msgs[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val m = msgs[p]
                val mine = m.uid == uid
                val ctx = this@MainActivity
                val wrap = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = if (mine) Gravity.END else Gravity.START
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                }
                val bubble = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundColor(if (mine) darkRed else card)
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                }
                val who = if (mine) "Ви" else m.name
                val head = TextView(ctx).apply {
                    text = who + (m.time?.let { "  " + fmt.format(it) } ?: "")
                    setTextColor(if (mine) Color.LTGRAY else red)
                    textSize = 12f
                }
                val body = TextView(ctx).apply {
                    text = m.text
                    setTextColor(Color.WHITE)
                    textSize = 17f
                }
                bubble.addView(head)
                bubble.addView(body)
                wrap.addView(bubble, LinearLayout.LayoutParams(-2, -2))
                return wrap
            }
        }

        val input = EditText(this).apply {
            hint = "Повідомлення"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 18f
            setBackgroundColor(card)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            filters = arrayOf(InputFilter.LengthFilter(500))
            maxLines = 4
        }
        val send = bigButton("НАДІСЛАТИ", red)
        send.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            input.setText("")
            db.collection("messages").add(
                hashMapOf(
                    "uid" to uid,
                    "name" to name,
                    "text" to text,
                    "time" to FieldValue.serverTimestamp()
                )
            ).addOnFailureListener {
                toast("Не вдалося надіслати: ${it.message}")
            }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
        row.addView(send, LinearLayout.LayoutParams(-2, dp(64)))

        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(row, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        reg?.remove()
        reg = db.collection("messages").orderBy("time").limitToLast(200)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    toast("Помилка чату: ${e.message}")
                    return@addSnapshotListener
                }
                msgs.clear()
                snap?.documents?.forEach { d ->
                    msgs.add(
                        Msg(
                            d.getString("uid") ?: "",
                            d.getString("name") ?: "?",
                            d.getString("text") ?: "",
                            d.getTimestamp("time", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()
                        )
                    )
                }
                (list.adapter as BaseAdapter).notifyDataSetChanged()
                list.setSelection(msgs.size - 1)
            }
    }
}
